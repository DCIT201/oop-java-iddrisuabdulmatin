import java.util.ArrayList;
import java.util.List;

public class RentalAgency {
    private final List<Vehicle> fleet;
    private String Customer;

    public RentalAgency() {
        this.fleet = new ArrayList<>();
    }

    public void addVehicle(Vehicle vehicle) {
        fleet.add(vehicle);
    }

    public Vehicle findAvailableVehicle(String model) {
        for (Vehicle vehicle : fleet) {
            if (vehicle.getModel().equalsIgnoreCase(model) && vehicle.isAvailable()) {
                return vehicle;
            }
        }
        return null;
    }

    public void processRental(Customer customer, String model, int days) {
        Vehicle vehicle = findAvailableVehicle(model);
        if (vehicle == null) {
            throw new IllegalStateException("No available vehicles of model: " + model);
        }
        vehicle.rent(Customer, days);
        customer.addRental(vehicle.getVehicleId());
        System.out.println("Rental processed: " + vehicle);
    }

    public void generateReport() {
        for (Vehicle vehicle : fleet) {
            System.out.println(vehicle);
        }
    }
}
