public class RentalTransaction {
    private final String transactionId;
    private final Customer customer;
    private final Vehicle vehicle;
    private final int rentalDays;
    private final double totalCost;

    public RentalTransaction(String transactionId, Customer customer, Vehicle vehicle, int rentalDays) {
        if (transactionId == null || customer == null || vehicle == null || rentalDays <= 0) {
            throw new IllegalArgumentException("Invalid transaction data.");
        }
        this.transactionId = transactionId;
        this.customer = customer;
        this.vehicle = vehicle;
        this.rentalDays = rentalDays;
        this.totalCost = vehicle.calculateRentalCost(rentalDays);
    }

    public String getTransactionId() {
        return transactionId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public int getRentalDays() {
        return rentalDays;
    }

    public double getTotalCost() {
        return totalCost;
    }

    @Override
    public String toString() {
        return String.format("Transaction[ID=%s, Customer=%s, Vehicle=%s, Days=%d, Cost=%.2f]",
                transactionId, customer.getName(), vehicle.getModel(), rentalDays, totalCost);
    }
}
