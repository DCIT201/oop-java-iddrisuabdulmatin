public class Car extends Vehicle implements Rentable {
    public Car(String vehicleId, String model, double baseRentalRate) {
        super(vehicleId, model, baseRentalRate);
    }

    @Override
    public double calculateRentalCost(int days) {
        return days * getBaseRentalRate();
    }

    @Override
    public boolean isAvailableForRental() {
        return isAvailable();
    }

    @Override
    public void rent(String customer, int days) {
        if (!isAvailableForRental()) {
            throw new IllegalStateException("Car is not available for rent.");
        }
        setAvailability(false);
        System.out.println("Car rented successfully for " + days + " days.");

    }

    @Override
    public void returnVehicle() {
        setAvailability(true);
        System.out.println("Car returned successfully.");
    }
}
