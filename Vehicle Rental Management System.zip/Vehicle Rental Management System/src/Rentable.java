public interface Rentable {
public void rent(String customer, int days);
public void returnVehicle();
}
