public class Motorcycle extends Vehicle implements Rentable{
    public Motorcycle(String vehicleId, String model, double baseRentalRate) {
        super(vehicleId, model, baseRentalRate);
    }

    @Override
    public double calculateRentalCost(int days) {
        return days * getBaseRentalRate() * 0.9; // Discount for motorcycles
    }

    @Override
    public boolean isAvailableForRental() {
        return isAvailable();
    }

    @Override
    public void rent(String customer, int days) {
        if (!isAvailableForRental()) {
            throw new IllegalStateException("Motorcycle is not available for rent.");
        }
        setAvailability(false);
        System.out.println("Motorcycle rented successfully for " + days + " days.");
    }

    @Override
    public void returnVehicle() {
        setAvailability(true);
        System.out.println("Motorcycle returned successfully.");
    }
}
