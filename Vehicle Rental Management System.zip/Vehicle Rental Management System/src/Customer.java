import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Customer {
    private final String customerId;
    private final String name;
    private final List<String> rentalHistory;

    public Customer(String customerId, String name) {
        if (customerId == null || name == null) {
            throw new IllegalArgumentException("Invalid customer data.");
        }
        this.customerId = customerId;
        this.name = name;
        this.rentalHistory = new ArrayList<>();
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public List<String> getRentalHistory() {
        return Collections.unmodifiableList(rentalHistory);
    }

    public void addRental(String vehicleId) {
        rentalHistory.add(vehicleId);
    }
}
