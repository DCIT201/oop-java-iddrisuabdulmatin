public class Main {
    public static void main(String[] args) {
        RentalAgency agency = new RentalAgency();
        agency.addVehicle(new Car("C001", "Toyota Corolla", 50));
        agency.addVehicle(new Motorcycle("M001", "Yamaha R3", 30));
        agency.addVehicle(new Truck("T001", "Ford F-150", 100));

        Customer customer = new Customer("CU001", "John Doe");

        try {
            agency.processRental(customer, "Toyota Corolla", 3);
            agency.processRental(customer, "Yamaha R3", 5);
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        agency.generateReport();
    }
}